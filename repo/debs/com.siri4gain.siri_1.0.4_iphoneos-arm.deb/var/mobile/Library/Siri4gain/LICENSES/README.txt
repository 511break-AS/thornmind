Siri4gain by Alberto Sanfelice includes the following third-party components.

Whisper speech recognition models (ggml-tiny.en-q8_0.bin, ggml-tiny-q8_0.bin)
  OpenAI Whisper, code and model weights under the MIT License (whisper-model-MIT.txt).
  Converted to ggml format by the whisper.cpp project.

whisper.cpp / ggml (in whisperd)
  MIT License, Copyright (c) 2023 Georgi Gerganov (whisper.cpp-MIT.txt).

llama.cpp (in s4g-llm)
  MIT License, Copyright (c) 2023 Georgi Gerganov (llama.cpp-MIT.txt).

SmolLM2-135M-Instruct (llm/SmolLM2-135M-Instruct-Q4_0.gguf)
  By Hugging Face (HuggingFaceTB), Apache License 2.0 (SmolLM2-Apache-2.0.txt).
  Modified: quantized to Q4_0 GGUF (bartowski/SmolLM2-135M-Instruct-GGUF).

Speex (in whisperd)
  BSD license, Copyright Xiph.org Foundation and others (speex-BSD.txt).
